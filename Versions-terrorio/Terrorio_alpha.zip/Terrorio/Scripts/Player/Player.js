export class player{
    start(){
        this.player_obj = {x : 550, y: 550, s: 5 , live: 100 , atack: 10,vx: 0, vy: 0, collicion: false, dead: false};
        this.skin_p = new Image();
        this.skin_p.src = 'Scripts/Player/Skins/Jonny.png'
    }
    animate(ctx,canvas){
        //ctx.drawImage(this.skin_p,this.player_obj.x,this.player_obj.y,16,16);
        ctx.fillStyle = "blue";
        ctx.fillRect(this.player_obj.x,this.player_obj.y,this.player_obj.s,this.player_obj.s)
        
    }
    gravity(){
        if (!this.player_obj.collicion){
            let force = 0.05;
            let vel = this.player_obj.vy + force;
            this.player_obj.vy = vel;
            this.player_obj.y += this.player_obj.vy;
        }
        if (this.player_obj.collicion && this.player_obj.vy != 0){
            this.player_obj.vy = 0;
        }
    }
    collicion_check(block){
      let cx = Math.floor(this.player_obj.x / this.player_obj.s);
      let cy = Math.floor((this.player_obj.y + this.player_obj.s) / this.player_obj.s);
      
      if (block[cx][cy].type != 0){
          this.player_obj.collicion = true;
      }
      else{
        this.player_obj.collicion = false;
      }
    }
    key_check(){
        document.addEventListener('keydown',(event) => {
            let speed = 5;
            this.left = false;
            this.right = false;
            this.space = false;
            if (event.key === 'd'){
                this.left = true;
            }
            else if (event.key === 'a'){
                this.right = true;   
            }
            else if (event.key === ' '){
                
            }
        });
        document.addEventListener('keyup',(event) => {
            if (event.key === 'd'){
                this.left = false;
            }
            else if (event.key === 'a'){
                this.right = false;  
            }
            else if (event.key === ' '){
                
            }
        });
    }
    move(){
        let speed = 0.1;
        if (this.left){
            this.player_obj.vx += speed;
        }
        else if (this.right){
            this.player_obj.vx -= speed;
        }
        else if (!this.left || !this.right){
            this.player_obj.vx = 0;
        }
        this.player_obj.x += this.player_obj.vx;
    }
    dead(){
        if (this.palyer_obj.live <= 0){
            this.player_obj.dead = true;
        }
        else if (this.palyer_obj.dead){
            
        }
    }
    get_player(){
        let player = this.player_obj;
        return player;
    }
}