export async function lector(link){
    try{
        const var1 = link
        const extractor = await fetch(var1);
        const text = await extractor.text();
    
        const island = text.split("\n").map(linea => linea.trim().split(","));
        
        return island;
    }
    catch (error) {
        console.error("El fetch falló de verdad:", error);
        return null; // Evita que el resto del código se rompa críticamente
    }
};