export class World{
    constructor(){
        
    }
    // world settings
    settings(difficulty,help,mode){
        this.difficulty = difficulty;
        this.help = help;
        this.mode = mode;
        
    }
    // create the array of world
    start(){
        let lng = 500;
        this.world_title = []; 
        for (let i = 0; i < lng; i++){
            this.world_title[i] = [];
            for (let j = 0; j < lng; j++){
                let seed = Math.floor(Math.random() * 10000);
                this.world_title[i][j] = {x: i, y: j, id : seed + (i * lng) + j, type : "0", ore : "none"};
            }
        }
        return this.world_title;
    }
    draw(canvas,ctx,world_title,v1,v2){
        let dis = 0;
        let tam = world_title.length;
        const size = 5;
        for (let x = 0; x < tam; x++){
            for (let y = 0 ; y < tam; y++){
                if (world_title[x][y].x < v1 && world_title[x][y].x > 0 && world_title[x][y].y < v2 && world_title[x][y].y > 0){
                    switch(world_title[x][y].type){
                        case "1" : ctx.fillStyle = "rgb(0," + (100 + (world_title[x][y].id % 30)) + ",0)"; break;
                        case "2" : ctx.fillStyle = "rgb(" + (100 + (world_title[x][y].id % 30)) + "," + (100 + (world_title[x][y].id % 30)) + "," + (100 + (world_title[x][y].id % 30)) + ")"; break;
                        case "3" : ctx.fillStyle = "rgb(" + (100 + (world_title[x][y].id % 30)) + "," + (100 + (world_title[x][y].id % 30)) + ",0)"; break;
                        case "4" : ctx.fillStyle = "rgb(100,100,0)";
                    }
                    if (world_title[x][y].type !== "0" ){
                    
                    ctx.fillRect(x * (size + dis),y * size , size , size);
                    
                    }
                }
                
            }
        }
    }
}