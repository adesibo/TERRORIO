import {World} from "./Terrain/Generate.js";
import {lector} from "./Terrain/Island_scripts/Lector_island.js";
import {spawner} from "./Terrain/Island_scripts/Islands_spawners.js";
import {player} from "./Player/Player.js";

const cam = document.getElementById('camera');
const ctx = cam.getContext('2d');

const island_1 = "./Scripts/Terrain/Island_scripts/Islands/Island_1.txt"
const island_2 = "./Scripts/Terrain/Island_scripts/Islands/Island_2.txt"
const island_3 = "./Scripts/Terrain/Island_scripts/Islands/Island_3.txt"
const island_4 = "./Scripts/Terrain/Island_scripts/Islands/Island_4.txt"
const par1 = new Image();
const par2 = new Image();
par1.src = "./Scripts/paralax/p1.png";
par2.src = "./Scripts/paralax/p2.png";

const w = new World();
const spawn = new spawner();
const pla = new player();

const [lect1, lect2 ,lect3,lect4] = await Promise.all([lector(island_1),lector(island_2),lector(island_3),lector(island_4)]);
const list = [lect1,lect2,lect3,lect4];

let matrix = w.start();

for (let i = 0; i < 200; i++){
    for (let j = 0; j < list.length; j++){
        spawn.start(list[j],matrix);
    }
}

pla.start();

const cs = cam.width
const cs2 = cam.height;
pla.key_check();
let playe = pla.get_player();
const lis = [par1,par2]

function loop(){
    let camX = playe.x - cs / 2;
    let camY = playe.y - cs2 / 2;
    

    ctx.clearRect(0,0,cam.width,cam.height);

    ctx.save();
    ctx.translate(-camX ,-camY);

    pla.move();
    pla.collicion_check(matrix);
    pla.gravity();
    
    
    
    w.draw(cam,ctx,matrix,cs,cs2);
    pla.animate(ctx,cam);

    ctx.restore();
    
    requestAnimationFrame(loop);
}
loop();