export class player{
    start(){
        this.player_obj = {x : 250, y: 250, s: 5 , live: 100 , atack: 10,vx: 0,vy: 0, collicion: false};
        this.skin_p = new Image();
        this.skin_p.src = 'Scripts/Player/Skins/Jonny.png'
    }
    animate(ctx,canvas,){
        //ctx.drawImage(this.skin_p,this.player_obj.x,this.player_obj.y,16,16);
        ctx.fillStyle = "blue";
        ctx.fillRect(this.player_obj.x,this.player_obj.y,this.player_obj.s,this.player_obj.s)
        
    }
    gravity(){
        if (this.player_obj.collicion === false){
            let force = 0.05;
            let vel = this.player_obj.vy + force;
            this.player_obj.vy = vel;
            this.player_obj.y += this.player_obj.vy;
        }
    }
    collicion_check(block){
    
      let cx = Math.floor(this.player_obj.x / this.player_obj.s);
      let cy = Math.floor((this.player_obj.y + this.player_obj.s) / this.player_obj.s);
      console.log(cx,cy)
      
      if (block[cx][cy].type === "1" ){
          this.player_obj.collicion = true;
          this.player_obj.vy = 0;
          
      }
    
    }
}