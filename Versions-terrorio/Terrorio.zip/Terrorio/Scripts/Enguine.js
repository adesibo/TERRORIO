import {World} from "./Terrain/Generate.js";
import {lector} from "./Terrain/Island_scripts/Lector_island.js";
import {spawner} from "./Terrain/Island_scripts/Islands_spawners.js";
import {player} from "./Player/Player.js";

const cam = document.getElementById('camera');
const ctx = cam.getContext('2d');

const island_1 = "./Scripts/Terrain/Island_scripts/Islands/Island_1.txt"
const island_2 = "./Scripts/Terrain/Island_scripts/Islands/Island_2.txt"
const island_3 = "./Scripts/Terrain/Island_scripts/Islands/Island_3.txt"

const w = new World();
const spawn = new spawner();
const pla = new player();

const [lect1, lect2 ,lect3] = await Promise.all([
    lector(island_1),
    lector(island_2),
    lector(island_3)
]);
const list = [lect1,lect2,lect3];

let matrix = w.start();
let num = 100 + Math.random() * 100

for (let i = 0; i < Math.floor(num); i++){
    for (let j = 0; j < list.length; j++){
        spawn.start(list[j],matrix);
    }
}

pla.start();
let colli = false;
const cs = 100
const cs2 = cam.height;
console.log(cs,cs2)

function loop(){
    ctx.clearRect(0,0,cam.width,cam.height);
    
    pla.collicion_check(matrix);
    pla.gravity();
    
    w.draw(cam,ctx,matrix,cs,cs2);
    pla.animate(ctx,cam);
    
    requestAnimationFrame(loop);
}
loop();