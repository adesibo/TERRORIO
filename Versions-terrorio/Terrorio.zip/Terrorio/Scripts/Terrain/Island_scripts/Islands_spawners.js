export class spawner{
    start(island,matrix){
        const c1 = Math.floor(Math.random() * matrix.length);
        const c2 = Math.floor(Math.random() * matrix[0].length);
        const prop = Math.floor(Math.random() * 100);
        for (let x = island.length - 1; x >= 0 ;x--){
            for (let y = island.length - 1; y >= 0 ;y--){
                if (c1 + x < matrix.length && c1 + x >= 0 && c2 + y < matrix.length && c2 + y >= 0){
                    if (prop <= 50){
                        const prop2 = Math.floor(Math.random() * 100);
                        if (island[y][x] === 3 && prop2 < 90){
                            island[y][x] === 'h';
                        }
                        matrix[c1 + x][c2 + y].type = island[y][x]
                    }
                   
                }
            }
        }
    }
}